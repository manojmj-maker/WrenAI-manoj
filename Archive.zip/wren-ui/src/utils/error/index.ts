export * from './dictionary';
